/bin/rm *.o Example
